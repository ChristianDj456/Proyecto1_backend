const Order = require('./pedidos.model');

async function createOrder(orderData) {
    try {
        const order = await Order.create(orderData);
        return order;
    } catch (error) {
        throw new Error('Error al crear el pedido');
    }
}

async function getOrderById(orderId) {
    try {
        const order = await Order.findById(orderId).populate('customer products');
        return order;
    } catch (error) {
        throw new Error('Pedido no encontrado');
    }
}



// Agrega más funciones de acciones según tus necesidades

module.exports = {
    createOrder,
    getOrderById
    // Agrega más funciones de acciones aquí
};