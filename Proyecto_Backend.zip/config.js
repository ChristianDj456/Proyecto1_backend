const JWT_SECRET = "secret";
module.exports = { JWT_SECRET };
