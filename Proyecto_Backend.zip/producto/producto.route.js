const express = require('express')
const router = express.Router();
const { readProductoConFiltros, createProducto, updateProducto, deleteProducto } = require("./producto.controller");
const { respondWithError } = require('../utils/functions');
const {authenticate} = require('../Auth/auth.middleware');  

async function GetProductos(req, res) {
    try {
        // llamada a controlador con los filtros
        const resultadosBusqueda = await readProductoConFiltros(req.query);
        res.status(200).json({
            ...resultadosBusqueda
        })
    } catch(e) {
        res.status(500).json({msg: ""})
    }
}

async function PostProducto(req, res) {
    try {
        // llamada a controlador con los datos
        const ownerId = req.user;
        //console.log(ownerId);
        const productoData = {
            ...req.body,
            propietario: ownerId // Asignar el nombre completo del propietario al campo propietario del producto
        };
        await createProducto(productoData);
        res.status(200).json({
            mensaje: "Exito. 👍"
        })
    } catch(e) {
        respondWithError(res, e);
    }
    return ownerId;
}


async function PatchProductos(req, res) {
    try {
        // llamada a controlador con los datos
        updateProducto(req.body);
        console.log(req.user)
        res.status(200).json({
            mensaje: "Exito. 👍"
        })
    } catch(e) {
        respondWithError(res, e);
    }
}


async function DeleteProductos(req, res) {
    try {
        // llamada a controlador con los datos
        deleteProducto(req.params.id);

        res.status(200).json({
            mensaje: "Exito. 👍"
        })
    } catch(e) {
        respondWithError(res, e);
    }
}

router.get("/", GetProductos);
router.post("/Create", authenticate, PostProducto);
router.patch("/", authenticate, PatchProductos);
router.delete("/:id", authenticate, DeleteProductos);


module.exports = router;
module.exports = PostProducto;
module.exports = GetProductos;